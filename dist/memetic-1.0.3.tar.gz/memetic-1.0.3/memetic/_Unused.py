'''
Created on Jan 14, 2016

@author: Dave

This module does not actually *do* anything.  It just gives an import hook, so that we can find the 
    package location in the filesystem.
'''
